ä = 1
µ = 2
蟒 = 3
x󠄀 = 4
មុ = 1
Q̇_per_meter = 4
