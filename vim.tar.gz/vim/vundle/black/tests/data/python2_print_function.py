#!/usr/bin/env python2
from __future__ import print_function

print('hello')
print(u'hello')
print(a, file=sys.stderr)

# output


#!/usr/bin/env python2
from __future__ import print_function

print("hello")
print(u"hello")
print(a, file=sys.stderr)
