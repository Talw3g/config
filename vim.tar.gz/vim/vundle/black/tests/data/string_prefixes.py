#!/usr/bin/env python3.6

name = R"Łukasz"
F"hello {name}"
B"hello"
r"hello"
fR"hello"

# output


#!/usr/bin/env python3.6

name = R"Łukasz"
f"hello {name}"
b"hello"
r"hello"
fR"hello"
